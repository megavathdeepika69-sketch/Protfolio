PORTFOLIO WEBSITE

Files included:
1. index.html
2. style.css

Instructions:
- Add your photo and rename it as photo.jpg
- Edit index.html with your details
- Upload all files to GitHub
- Enable GitHub Pages to make it live
